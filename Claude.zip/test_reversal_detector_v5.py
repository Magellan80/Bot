"""
Unit тесты для ReversalDetector v5.0
Запуск: pytest test_reversal_detector.py -v
"""

import pytest
import time
from reversal_detector_v5 import (
    ReversalDetector,
    ReversalPerformanceTracker,
    ReversalSignal
)


class TestReversalDetectorBasics:
    """Базовые тесты детектора"""
    
    def test_initialization_with_default_config(self):
        """Инициализация с дефолтной конфигурацией"""
        detector = ReversalDetector()
        assert detector.config is not None
        assert 'rsi_period' in detector.config
        assert detector.config['rsi_period'] == 14
    
    def test_initialization_with_custom_config(self):
        """Инициализация с кастомной конфигурацией"""
        custom_config = {
            'rsi_oversold': 30,
            'volume_spike_threshold': 2.5
        }
        detector = ReversalDetector(config=custom_config)
        assert detector.config['rsi_oversold'] == 30
        assert detector.config['volume_spike_threshold'] == 2.5
    
    def test_update_config(self):
        """Обновление конфигурации"""
        detector = ReversalDetector()
        detector.update_config({'rsi_overbought': 70})
        assert detector.config['rsi_overbought'] == 70
    
    def test_insufficient_data_returns_none(self):
        """Недостаточно данных возвращает None"""
        detector = ReversalDetector()
        
        # Только 30 свечей (нужно минимум 60)
        closes = [100 + i * 0.1 for i in range(30)]
        highs = [c + 1 for c in closes]
        lows = [c - 1 for c in closes]
        volumes = [1000] * 30
        
        result = detector.analyze(closes, highs, lows, volumes)
        assert result['reversal'] is None
        assert 'Not enough data' in result['filters']


class TestIndicators:
    """Тесты индикаторов"""
    
    def test_rsi_calculation(self):
        """Расчёт RSI"""
        detector = ReversalDetector()
        
        # Растущий тренд
        closes = [100 + i for i in range(50)]
        rsi = detector._rsi(closes, period=14)
        
        assert len(rsi) > 0
        assert all(0 <= r <= 100 for r in rsi)
        # В растущем тренде RSI должен быть > 50
        assert rsi[-1] > 50
    
    def test_ema_calculation(self):
        """Расчёт EMA"""
        detector = ReversalDetector()
        
        values = [10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20]
        ema = detector._ema(values, period=5)
        
        assert len(ema) > 0
        # EMA последнего значения должна быть близка к нему
        assert abs(ema[-1] - values[-1]) < 5
    
    def test_macd_histogram(self):
        """Расчёт MACD histogram"""
        detector = ReversalDetector()
        
        closes = [100 + i * 0.5 for i in range(100)]
        macd_hist = detector._macd_hist(closes)
        
        assert len(macd_hist) > 0
        # MACD histogram может быть положительным или отрицательным
    
    def test_obv_calculation(self):
        """Расчёт OBV"""
        detector = ReversalDetector()
        
        closes = [100, 101, 102, 101, 103]
        volumes = [1000, 1200, 1100, 900, 1300]
        
        obv = detector._obv(closes, volumes)
        
        assert len(obv) == len(closes)
        assert obv[0] == 0
        # OBV должен расти при росте цены с объёмом
        assert obv[-1] > obv[0]
    
    def test_atr_calculation(self):
        """Расчёт ATR"""
        detector = ReversalDetector()
        
        highs = [105, 106, 107, 108, 109]
        lows = [95, 96, 97, 98, 99]
        closes = [100, 101, 102, 103, 104]
        
        atr = detector._atr(highs, lows, closes, period=3)
        
        assert len(atr) > 0
        assert all(a > 0 for a in atr)


class TestSwingDetection:
    """Тесты детекции свингов"""
    
    def test_swing_high_detection(self):
        """Детекция swing high"""
        detector = ReversalDetector()
        
        # Создаём данные с явным swing high
        highs = [100, 101, 102, 105, 103, 102, 101]  # Пик на индексе 3
        lows = [95, 96, 97, 100, 98, 97, 96]
        
        swings = detector._swings(highs, lows, lookback=2)
        
        # Должен быть найден swing high
        high_swings = [s for s in swings if s['type'] == 'high']
        assert len(high_swings) > 0
    
    def test_swing_low_detection(self):
        """Детекция swing low"""
        detector = ReversalDetector()
        
        # Создаём данные с явным swing low
        highs = [105, 104, 103, 100, 102, 103, 104]
        lows = [100, 99, 98, 95, 97, 98, 99]  # Дно на индексе 3
        
        swings = detector._swings(highs, lows, lookback=2)
        
        # Должен быть найден swing low
        low_swings = [s for s in swings if s['type'] == 'low']
        assert len(low_swings) > 0


class TestDivergence:
    """Тесты дивергенций"""
    
    def test_regular_bullish_divergence(self):
        """Regular bullish divergence"""
        detector = ReversalDetector()
        
        # Создаём lower low в цене
        lows = [100] * 20 + [98, 100, 99, 100, 96, 100]  # Два лоу: 98 и 96 (lower low)
        highs = [l + 5 for l in lows]
        closes = [l + 2 for l in lows]
        
        # RSI делает higher low (расходится с ценой)
        rsi = [50] * 20 + [45, 50, 48, 50, 47, 50]  # Два лоу: 45 и 47 (higher low)
        
        swings = [
            {'type': 'low', 'index': 20},
            {'type': 'high', 'index': 22},
            {'type': 'low', 'index': 24},
        ]
        
        div_result = detector._advanced_divergence(rsi, closes, highs, lows, swings, 'RSI')
        
        assert div_result['type'] == 'bullish'
        assert div_result['hidden'] is False
        assert div_result['strength'] > 0
    
    def test_regular_bearish_divergence(self):
        """Regular bearish divergence"""
        detector = ReversalDetector()
        
        # Создаём higher high в цене
        highs = [100] * 20 + [102, 100, 101, 100, 104, 100]  # Два хая: 102 и 104 (higher high)
        lows = [h - 5 for h in highs]
        closes = [h - 2 for h in highs]
        
        # RSI делает lower high (расходится с ценой)
        rsi = [50] * 20 + [65, 50, 62, 50, 60, 50]  # Два хая: 65 и 60 (lower high)
        
        swings = [
            {'type': 'high', 'index': 20},
            {'type': 'low', 'index': 22},
            {'type': 'high', 'index': 24},
        ]
        
        div_result = detector._advanced_divergence(rsi, closes, highs, lows, swings, 'RSI')
        
        assert div_result['type'] == 'bearish'
        assert div_result['hidden'] is False


class TestBOS:
    """Тесты Break of Structure"""
    
    def test_bullish_bos(self):
        """Bullish BOS (пробой последнего swing high)"""
        detector = ReversalDetector()
        
        closes = [100] * 50 + [105]  # Последняя цена выше swing high
        
        swings = [
            {'type': 'high', 'index': 45},  # Swing high на 45-м индексе
            {'type': 'low', 'index': 48},
        ]
        
        bos, direction = detector._bos(closes, swings)
        
        assert bos is True
        assert direction == 'bullish'
    
    def test_bearish_bos(self):
        """Bearish BOS (пробой последнего swing low)"""
        detector = ReversalDetector()
        
        closes = [100] * 50 + [95]  # Последняя цена ниже swing low
        
        swings = [
            {'type': 'low', 'index': 45},  # Swing low на 45-м индексе с ценой ~100
            {'type': 'high', 'index': 48},
        ]
        
        bos, direction = detector._bos(closes, swings)
        
        assert bos is True
        assert direction == 'bearish'


class TestVolumeClimax:
    """Тесты Volume climax"""
    
    def test_bullish_volume_climax(self):
        """Bullish volume climax"""
        detector = ReversalDetector()
        
        volumes = [1000] * 30 + [4000]  # Спайк в 4x
        closes = [100] * 30 + [102]  # Рост цены
        highs = [c + 1 for c in closes]
        lows = [c - 0.5 for c in closes]  # Большое body
        
        climax, direction = detector._volume_climax(closes, highs, lows, volumes)
        
        assert climax is True
        assert direction == 'bullish'
    
    def test_bearish_volume_climax(self):
        """Bearish volume climax"""
        detector = ReversalDetector()
        
        volumes = [1000] * 30 + [4000]  # Спайк в 4x
        closes = [100] * 30 + [98]  # Падение цены
        highs = [c + 0.5 for c in closes]  # Большое body
        lows = [c - 1 for c in closes]
        
        climax, direction = detector._volume_climax(closes, highs, lows, volumes)
        
        assert climax is True
        assert direction == 'bearish'


class TestMarketRegime:
    """Тесты определения режима рынка"""
    
    def test_trending_regime(self):
        """Trending режим"""
        detector = ReversalDetector()
        
        # Сильный тренд
        closes = [100 + i for i in range(50)]
        highs = [c + 1 for c in closes]
        lows = [c - 1 for c in closes]
        atr = detector._atr(highs, lows, closes)
        
        regime = detector._detect_market_regime(closes, atr)
        
        assert regime == 'trending'
    
    def test_ranging_regime(self):
        """Ranging режим"""
        detector = ReversalDetector()
        
        # Боковик
        closes = [100 + (i % 3) for i in range(50)]  # Колебания в узком диапазоне
        highs = [c + 0.5 for c in closes]
        lows = [c - 0.5 for c in closes]
        atr = detector._atr(highs, lows, closes)
        
        regime = detector._detect_market_regime(closes, atr)
        
        assert regime == 'ranging'
    
    def test_volatile_regime(self):
        """Volatile режим"""
        detector = ReversalDetector()
        
        # Высокая волатильность
        closes = [100 + (10 if i % 2 == 0 else -10) for i in range(50)]
        highs = [c + 5 for c in closes]
        lows = [c - 5 for c in closes]
        atr = detector._atr(highs, lows, closes)
        
        regime = detector._detect_market_regime(closes, atr)
        
        assert regime == 'volatile'


class TestOrderFlow:
    """Тесты Order Flow анализа"""
    
    def test_bullish_order_flow(self):
        """Bullish order flow"""
        detector = ReversalDetector()
        
        # Больше агрессивных покупок
        trades = [
            {'isBuyerMaker': False, 'qty': '100'},  # Taker buy
            {'isBuyerMaker': False, 'qty': '150'},  # Taker buy
            {'isBuyerMaker': False, 'qty': '120'},  # Taker buy
            {'isBuyerMaker': True, 'qty': '50'},    # Taker sell
        ] * 20
        
        flow = detector._order_flow(trades)
        
        assert flow['bias'] == 'bullish'
        assert flow['delta'] > 0
        assert flow['aggressive_buys'] > flow['aggressive_sells']
    
    def test_bearish_order_flow(self):
        """Bearish order flow"""
        detector = ReversalDetector()
        
        # Больше агрессивных продаж
        trades = [
            {'isBuyerMaker': True, 'qty': '100'},   # Taker sell
            {'isBuyerMaker': True, 'qty': '150'},   # Taker sell
            {'isBuyerMaker': True, 'qty': '120'},   # Taker sell
            {'isBuyerMaker': False, 'qty': '50'},   # Taker buy
        ] * 20
        
        flow = detector._order_flow(trades)
        
        assert flow['bias'] == 'bearish'
        assert flow['delta'] < 0
        assert flow['aggressive_sells'] > flow['aggressive_buys']


class TestMTFConfluence:
    """Тесты Multi-timeframe confluence"""
    
    def test_bullish_mtf_confluence(self):
        """Bullish MTF confluence"""
        detector = ReversalDetector()
        
        # Оба таймфрейма в uptrend
        klines_1h = [[0, 100 + i, 101 + i, 99 + i, 100.5 + i, 1000] for i in range(50)]
        klines_4h = [[0, 100 + i * 2, 102 + i * 2, 98 + i * 2, 101 + i * 2, 5000] for i in range(50)]
        
        mtf = detector._mtf_confluence(klines_1h, klines_4h)
        
        assert mtf['direction'] == 'bullish'
        assert mtf['strength'] > 0
        assert '1h' in mtf['timeframes_aligned']
        assert '4h' in mtf['timeframes_aligned']
    
    def test_bearish_mtf_confluence(self):
        """Bearish MTF confluence"""
        detector = ReversalDetector()
        
        # Оба таймфрейма в downtrend
        klines_1h = [[0, 100 - i, 101 - i, 99 - i, 100.5 - i, 1000] for i in range(50)]
        klines_4h = [[0, 100 - i * 2, 102 - i * 2, 98 - i * 2, 101 - i * 2, 5000] for i in range(50)]
        
        mtf = detector._mtf_confluence(klines_1h, klines_4h)
        
        assert mtf['direction'] == 'bearish'
        assert mtf['strength'] > 0


class TestPerformanceTracker:
    """Тесты Performance Tracker"""
    
    def test_add_signal(self, tmp_path):
        """Добавление сигнала"""
        db_file = tmp_path / "test_rev_perf.json"
        tracker = ReversalPerformanceTracker(str(db_file))
        
        signal_id = tracker.add_signal(
            direction='bullish',
            rating=75,
            entry_price=50000.0,
            filters=['BOS', 'RSI divergence']
        )
        
        assert signal_id in tracker.signals
        assert tracker.stats['total_signals'] == 1
        assert tracker.stats['bullish_signals'] == 1
    
    def test_check_outcome_success(self, tmp_path):
        """Проверка успешного результата"""
        db_file = tmp_path / "test_rev_perf.json"
        tracker = ReversalPerformanceTracker(str(db_file))
        
        signal_id = tracker.add_signal(
            direction='bullish',
            rating=75,
            entry_price=50000.0,
            filters=['BOS']
        )
        
        # Подделываем timestamp чтобы прошло 15+ минут
        tracker.signals[signal_id].timestamp = time.time() - 1000
        
        # Проверяем с ценой выше (успех для bullish)
        tracker.check_outcome(signal_id, 50300.0)
        
        assert tracker.signals[signal_id].outcome_checked is True
        assert tracker.signals[signal_id].outcome_success is True
        assert tracker.signals[signal_id].pnl_percent > 0
    
    def test_check_outcome_failure(self, tmp_path):
        """Проверка неудачного результата"""
        db_file = tmp_path / "test_rev_perf.json"
        tracker = ReversalPerformanceTracker(str(db_file))
        
        signal_id = tracker.add_signal(
            direction='bullish',
            rating=65,
            entry_price=50000.0,
            filters=['Volume']
        )
        
        tracker.signals[signal_id].timestamp = time.time() - 1000
        
        # Проверяем с ценой ниже (провал для bullish)
        tracker.check_outcome(signal_id, 49800.0)
        
        assert tracker.signals[signal_id].outcome_checked is True
        assert tracker.signals[signal_id].outcome_success is False
        assert tracker.signals[signal_id].pnl_percent < 0


class TestWeightedVoting:
    """Тесты взвешенного голосования"""
    
    def test_bullish_voting_trending_market(self):
        """Bullish голосование в trending рынке"""
        detector = ReversalDetector()
        
        signals = {
            'bos': 'bullish',
            'rsi_div': 'bullish',
            'volume': 'bullish',
            'candle': None,
            'htf': 'bullish',
        }
        
        rsi = [40]
        macd_hist = [0.5, -0.1, 0.2]  # Zero-cross bullish
        
        result = detector._weighted_voting(signals, 'trending', rsi, macd_hist)
        
        assert result['direction'] == 'bullish'
        assert result['confidence'] > 50
    
    def test_bearish_voting_ranging_market(self):
        """Bearish голосование в ranging рынке"""
        detector = ReversalDetector()
        
        signals = {
            'bos': 'bearish',
            'rsi_div': 'bearish',
            'macd_div': 'bearish',
            'volume': None,
            'candle': 'bearish',
        }
        
        rsi = [70]
        macd_hist = [-0.5, 0.1, -0.2]  # Zero-cross bearish
        
        result = detector._weighted_voting(signals, 'ranging', rsi, macd_hist)
        
        assert result['direction'] == 'bearish'
        assert result['confidence'] > 50


class TestFullAnalysis:
    """Интеграционные тесты полного анализа"""
    
    def test_full_bullish_reversal_detection(self):
        """Полный анализ bullish разворота"""
        detector = ReversalDetector()
        
        # Создаём данные с явным downtrend и признаками разворота
        closes = [100 - i * 0.5 for i in range(50)] + [75, 76, 78]  # Падение потом рост
        highs = [c + 2 for c in closes]
        lows = [c - 2 for c in closes]
        volumes = [1000] * 50 + [3000, 3500, 4000]  # Volume spike
        
        result = detector.analyze(closes, highs, lows, volumes)
        
        # Может быть reversal или None в зависимости от строгости фильтров
        assert 'reversal' in result
        assert 'rating' in result
        assert 'filters' in result
    
    def test_full_analysis_with_all_features(self):
        """Полный анализ со всеми фичами"""
        detector = ReversalDetector()
        
        # Базовые данные
        closes = [100 + i * 0.3 for i in range(80)]
        highs = [c + 1 for c in closes]
        lows = [c - 1 for c in closes]
        volumes = [1000 + i * 10 for i in range(80)]
        
        # Дополнительные данные
        ob_imbalance = 20  # Buy pressure
        klines_1h = [[0, c, c + 2, c - 2, c + 1, v] for c, v in zip(closes, volumes)]
        klines_4h = klines_1h
        trades = [{'isBuyerMaker': False, 'qty': '100'} for _ in range(100)]
        volume_profile = {'poc': 100, 'high_volume_levels': [100, 105, 110]}
        liquidity_map = {'strongest_zone': {'price': 98, 'type': 'support'}}
        
        result = detector.analyze(
            closes, highs, lows, volumes,
            ob_imbalance=ob_imbalance,
            klines_1h=klines_1h,
            klines_4h=klines_4h,
            trades=trades,
            volume_profile=volume_profile,
            liquidity_map=liquidity_map
        )
        
        assert result is not None
        assert 'reversal' in result
        assert 'rating' in result
        assert 'confidence' in result


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
