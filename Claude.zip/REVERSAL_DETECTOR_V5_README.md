# 📚 ReversalDetector v5.0 - Полная документация

## 🎯 Обзор

ReversalDetector v5.0 — профессиональный детектор разворотов с расширенными возможностями:
- Адаптивные параметры
- Performance tracking
- Multi-timeframe confluence
- Order flow analysis
- Advanced divergence
- Weighted voting
- ML integration (опционально)

---

## 📦 Установка

```bash
# Нет дополнительных зависимостей
# Всё работает на стандартном Python 3.8+
```

---

## 🚀 Быстрый старт

### Базовое использование

```python
from reversal_detector_v5 import ReversalDetector

# Инициализация
detector = ReversalDetector()

# Подготовка данных
closes = [100, 101, 102, ...]  # Минимум 60 свечей
highs = [105, 106, 107, ...]
lows = [95, 96, 97, ...]
volumes = [1000, 1200, 1100, ...]

# Анализ
result = detector.analyze(closes, highs, lows, volumes)

if result['reversal']:
    print(f"🔄 {result['reversal'].upper()} разворот!")
    print(f"Рейтинг: {result['rating']}/100")
    print(f"Уверенность: {result['confidence']}%")
    print(f"Фильтры: {result['filters']}")
```

### С кастомной конфигурацией

```python
custom_config = {
    'rsi_oversold': 30,          # Более агрессивно
    'rsi_overbought': 70,
    'volume_spike_threshold': 2.5,  # Менее строго
    'min_score': 40,              # Ниже порог
}

detector = ReversalDetector(config=custom_config)
```

### Полный анализ со всеми фичами

```python
result = detector.analyze(
    closes=closes,
    highs=highs,
    lows=lows,
    volumes=volumes,
    
    # Дополнительные данные (опционально)
    ob_imbalance=15,              # Orderbook imbalance
    klines_1h=klines_1h,          # Для MTF confluence
    klines_4h=klines_4h,
    trades=recent_trades,         # Для order flow
    volume_profile=vol_profile,   # POC/HVN данные
    liquidity_map=liq_map         # Ликвидность
)
```

---

## ⚙️ Конфигурация

### Все параметры

```python
default_config = {
    # RSI
    'rsi_period': 14,
    'rsi_oversold': 35,
    'rsi_overbought': 65,
    'rsi_extreme_oversold': 25,
    'rsi_extreme_overbought': 75,
    
    # Trend
    'atr_trend_multiplier': 3.0,
    'min_trend_move': 20,
    
    # Volume
    'volume_spike_threshold': 3.0,
    'volume_lookback': 20,
    
    # BOS
    'bos_buffer_pct': 0.001,
    
    # Swings
    'swing_lookback': 3,
    
    # HTF
    'htf_sma_period': 40,
    'htf_threshold_pct': 1.5,
    
    # ATR Filter
    'atr_ultra_low': 0.4,
    'atr_low': 0.9,
    'atr_normal': 2.0,
    'atr_high': 4.0,
    
    # Scoring
    'min_score': 30,
    'divergence_weight': 18,
    'bos_weight': 24,
    'volume_weight': 14,
    'candle_weight': 10,
    'htf_weight': 10,
    
    # Habr strategy
    'bb_period': 20,
    'bb_mult': 2.0,
    'habr_min_atr': 0.2,
    'habr_max_atr': 5.0,
    'habr_min_score': 30,
    
    # Features
    'enable_hidden_divergence': True,
    'enable_order_flow': True,
    'enable_volume_profile': True,
    'enable_liquidity_sweep': True,
    'enable_ml_adjustment': False,
}
```

### Динамическое обновление

```python
detector.update_config({
    'min_score': 50,  # Строже
    'rsi_oversold': 25  # Экстремальные значения
})
```

---

## 📊 Структура результата

### Основной результат analyze()

```python
{
    'reversal': 'bullish' | 'bearish' | None,
    'rating': 0-100,
    'confidence': 0-100,
    'filters': [
        'Trend: bullish_trend',
        'RSI Regular bullish divergence (strength=65)',
        'BOS/CHOCH bullish',
        'Volume climax bullish',
        'MTF Confluence: bullish (85)',
        'Order Flow: bullish (delta=1250)',
        ...
    ],
    'signal_id': 'rev_1707483625123',
    'market_regime': 'trending' | 'ranging' | 'volatile'
}
```

### Habr стратегия

```python
{
    'direction': 'bullish' | 'bearish',
    'rating': 0-100
}
# или None если условий нет
```

---

## 🔍 Основные фичи

### 1. Advanced Divergence

**Regular divergence:**
- Bullish: цена lower low, индикатор higher low
- Bearish: цена higher high, индикатор lower high

**Hidden divergence:**
- Bullish: цена higher low, индикатор lower low (продолжение uptrend)
- Bearish: цена lower high, индикатор higher high (продолжение downtrend)

**Strength scoring:**
- Оценка силы дивергенции (0-100)
- Учитывает угол расхождения между ценой и индикатором

```python
div_result = detector._advanced_divergence(
    rsi, closes, highs, lows, swings, 'RSI'
)

# {
#     'type': 'bullish',
#     'hidden': False,
#     'strength': 75,
#     'swings_involved': 2
# }
```

### 2. Multi-Timeframe Confluence

Проверка совпадения тренда на нескольких таймфреймах:

```python
mtf_result = detector._mtf_confluence(klines_1h, klines_4h)

# {
#     'direction': 'bullish',
#     'strength': 85,
#     'timeframes_aligned': ['1h', '4h']
# }
```

**Когда использовать:**
- Для подтверждения разворота на младшем TF
- Фильтрации контртрендовых сделок
- Повышения confidence сигнала

### 3. Order Flow Analysis

Анализ агрессивных покупок/продаж из реальных сделок:

```python
flow_result = detector._order_flow(trades, lookback=100)

# {
#     'bias': 'bullish',
#     'aggressive_buys': 67,
#     'aggressive_sells': 33,
#     'delta': 1250.5  # Buy volume - Sell volume
# }
```

**Интерпретация:**
- `bias = 'bullish'` — преобладают агрессивные покупки
- `delta > 0` — накопленный объём покупок больше
- Полезно для определения "real" спроса/предложения

### 4. Volume Profile Integration

Проверка разворота около значимых уровней:

```python
vp_result = detector._volume_reversal_zones(closes, volume_profile)

# {
#     'near_poc': True,  # Около Point of Control
#     'near_hvn': False,  # Около High Volume Node
#     'zone_strength': 40
# }
```

**Логика:**
- POC — уровень с максимальным объёмом (сильная поддержка/сопротивление)
- HVN — зоны высокого объёма
- Разворот около этих зон имеет больше шансов на успех

### 5. Liquidity Sweep Detection

Детекция "sweep liquidity then reverse":

```python
liq_result = detector._liquidity_reversal(liquidity_map, current_price)

# {
#     'swept': True,
#     'direction': 'bullish',
#     'zone_price': 49850.0
# }
```

**Как это работает:**
- Цена пробивает зону ликвидности (support/resistance)
- Забирает stop-loss'ы
- Затем разворачивается в обратную сторону
- Классическая Smart Money тактика

### 6. Weighted Voting System

Финальное решение принимается взвешенным голосованием:

```python
signals_dict = {
    'bos': 'bullish',      # вес 30
    'rsi_div': 'bullish',  # вес 18
    'volume': 'bullish',   # вес 15
    'candle': None,
    'htf': 'bullish',      # вес 15
}

voting_result = detector._weighted_voting(
    signals_dict, 
    market_regime='trending',
    rsi=rsi,
    macd_hist=macd_hist
)

# {
#     'direction': 'bullish',
#     'confidence': 78
# }
```

**Веса адаптируются:**
- `trending` — больше вес BOS, меньше divergence
- `ranging` — больше вес divergence, меньше BOS
- `volatile` — больше вес volume и candles

### 7. Dynamic ATR Filter

Адаптивный фильтр шума на основе ATR:

```python
atr_ok, vol_regime = detector._dynamic_atr_filter(atr, closes)

# (True, 'normal')  — можно торговать
# (False, 'ultra_low')  — слишком мало движения
```

**Режимы:**
- `ultra_low` (< 0.4%) — отфильтровано
- `low` (0.4-0.9%) — ок
- `normal` (0.9-2.0%) — ок
- `high` (2.0-4.0%) — ок
- `extreme` (> 4.0%) — ок, но осторожно

---

## 📈 Performance Tracking

### Автоматическое отслеживание

Каждый сигнал автоматически добавляется в трекер:

```python
result = detector.analyze(...)

if result['reversal']:
    signal_id = result['signal_id']
    # Сохранено в performance tracker
```

### Проверка результата

Через 15+ минут проверяем outcome:

```python
current_price = 50500.0  # Текущая цена
detector.check_signal_outcome(signal_id, current_price)
```

### Статистика

```python
stats = detector.get_performance_stats()
print(stats)

# 📊 Reversal Detector Stats:
# Total: 127 | Bullish: 68 | Bearish: 59
# Win Rates: Bullish=64.7% | Bearish=57.6%
# Avg PnL: 1.23%
# Best Indicators: BOS=72.1% | RSI Div=61.3%
```

### Лучшие фильтры

Трекер автоматически вычисляет какие фильтры дают лучшие результаты:

```python
tracker = detector.performance_tracker
best_filters = tracker.stats['best_filters']

# {
#     'BOS/CHOCH bullish': 0.721,
#     'RSI Regular bullish divergence': 0.613,
#     'Volume climax': 0.589,
#     ...
# }
```

---

## 💡 Примеры использования

### Пример 1: Интеграция в торгового бота

```python
from reversal_detector_v5 import ReversalDetector

class TradingBot:
    def __init__(self):
        self.detector = ReversalDetector(config={
            'min_score': 60,
            'rsi_oversold': 30,
        })
    
    async def analyze_reversal(self, symbol):
        # Получаем данные
        klines_1m = await self.fetch_klines(symbol, '1m', 100)
        klines_1h = await self.fetch_klines(symbol, '1h', 50)
        klines_4h = await self.fetch_klines(symbol, '4h', 50)
        trades = await self.fetch_recent_trades(symbol, 200)
        
        # Извлекаем
        closes = [float(k[4]) for k in klines_1m]
        highs = [float(k[2]) for k in klines_1m]
        lows = [float(k[3]) for k in klines_1m]
        volumes = [float(k[5]) for k in klines_1m]
        
        # Анализ
        result = self.detector.analyze(
            closes, highs, lows, volumes,
            klines_1h=klines_1h,
            klines_4h=klines_4h,
            trades=trades
        )
        
        if result['reversal'] and result['rating'] >= 70:
            # Входим в сделку
            await self.enter_position(
                symbol=symbol,
                direction=result['reversal'],
                confidence=result['confidence']
            )
            
            return result
        
        return None
```

### Пример 2: Backtesting

```python
class ReversalBacktester:
    def __init__(self):
        self.detector = ReversalDetector()
        self.trades = []
    
    def backtest(self, historical_data):
        """Бэктест на исторических данных"""
        
        for i in range(100, len(historical_data)):
            # Берём окно в 100 свечей
            window = historical_data[i-100:i]
            
            closes = [d['close'] for d in window]
            highs = [d['high'] for d in window]
            lows = [d['low'] for d in window]
            volumes = [d['volume'] for d in window]
            
            # Анализ
            result = self.detector.analyze(closes, highs, lows, volumes)
            
            if result['reversal']:
                # Симулируем сделку
                entry_price = closes[-1]
                
                # Проверяем что произошло через 10 свечей
                future_prices = [historical_data[i+j]['close'] for j in range(1, 11)]
                
                if result['reversal'] == 'bullish':
                    # Проверяем рост
                    max_profit = max((p - entry_price) / entry_price * 100 for p in future_prices)
                    max_loss = min((p - entry_price) / entry_price * 100 for p in future_prices)
                else:  # bearish
                    # Проверяем падение
                    max_profit = max((entry_price - p) / entry_price * 100 for p in future_prices)
                    max_loss = min((entry_price - p) / entry_price * 100 for p in future_prices)
                
                self.trades.append({
                    'direction': result['reversal'],
                    'rating': result['rating'],
                    'entry': entry_price,
                    'max_profit': max_profit,
                    'max_loss': max_loss,
                    'success': max_profit > 0.5,
                })
        
        # Анализ результатов
        self.analyze_results()
    
    def analyze_results(self):
        """Анализ результатов бэктеста"""
        if not self.trades:
            print("Нет сделок")
            return
        
        total = len(self.trades)
        successful = sum(1 for t in self.trades if t['success'])
        
        print(f"Всего сделок: {total}")
        print(f"Успешных: {successful}")
        print(f"Win Rate: {successful/total:.1%}")
        
        avg_profit = sum(t['max_profit'] for t in self.trades if t['success']) / successful if successful > 0 else 0
        avg_loss = sum(abs(t['max_loss']) for t in self.trades if not t['success']) / (total - successful) if (total - successful) > 0 else 0
        
        print(f"Средняя прибыль: {avg_profit:.2f}%")
        print(f"Средний убыток: {avg_loss:.2f}%")
        print(f"Risk/Reward: {avg_profit/avg_loss:.2f}" if avg_loss > 0 else "N/A")
```

### Пример 3: Адаптация к конкретному символу

```python
class SymbolAdaptiveDetector:
    def __init__(self, symbol):
        self.symbol = symbol
        self.detector = ReversalDetector()
        self.calibration_data = []
    
    def calibrate(self, historical_signals):
        """Калибровка на основе истории символа"""
        
        # Анализируем успешность разных фильтров
        filter_performance = {}
        
        for signal in historical_signals:
            for filter_name in signal['filters']:
                if filter_name not in filter_performance:
                    filter_performance[filter_name] = {'total': 0, 'success': 0}
                
                filter_performance[filter_name]['total'] += 1
                if signal['outcome_success']:
                    filter_performance[filter_name]['success'] += 1
        
        # Определяем лучшие фильтры
        best_filters = sorted(
            filter_performance.items(),
            key=lambda x: x[1]['success'] / x[1]['total'] if x[1]['total'] > 0 else 0,
            reverse=True
        )[:5]
        
        print(f"Лучшие фильтры для {self.symbol}:")
        for filter_name, stats in best_filters:
            win_rate = stats['success'] / stats['total'] if stats['total'] > 0 else 0
            print(f"  {filter_name}: {win_rate:.1%}")
        
        # Адаптируем веса
        # (можно реализовать автоматическую корректировку config)
```

### Пример 4: Real-time мониторинг

```python
import asyncio

class ReversalMonitor:
    def __init__(self, symbols):
        self.symbols = symbols
        self.detector = ReversalDetector()
    
    async def monitor_loop(self):
        """Непрерывный мониторинг разворотов"""
        
        while True:
            for symbol in self.symbols:
                try:
                    result = await self.check_reversal(symbol)
                    
                    if result and result['reversal']:
                        await self.send_alert(symbol, result)
                    
                except Exception as e:
                    print(f"Error monitoring {symbol}: {e}")
            
            await asyncio.sleep(30)  # Проверка каждые 30 сек
    
    async def check_reversal(self, symbol):
        """Проверка разворота для символа"""
        # Получаем данные
        klines = await fetch_klines(symbol, '5m', 100)
        
        closes = [float(k[4]) for k in klines]
        highs = [float(k[2]) for k in klines]
        lows = [float(k[3]) for k in klines]
        volumes = [float(k[5]) for k in klines]
        
        return self.detector.analyze(closes, highs, lows, volumes)
    
    async def send_alert(self, symbol, result):
        """Отправка алерта"""
        message = (
            f"🔔 REVERSAL ALERT: {symbol}\n"
            f"Direction: {result['reversal'].upper()}\n"
            f"Rating: {result['rating']}/100\n"
            f"Confidence: {result['confidence']}%\n"
            f"Filters: {', '.join(result['filters'][:3])}"
        )
        
        # Отправляем в Telegram/Discord/etc
        await send_telegram(message)
```

---

## 🧪 Тестирование

### Запуск тестов

```bash
pytest test_reversal_detector_v5.py -v
```

### Покрытие

```bash
pytest test_reversal_detector_v5.py --cov=reversal_detector_v5 --cov-report=html
```

---

## 📊 Сравнение v4.2 → v5.0

| Функционал | v4.2 | v5.0 |
|-----------|------|------|
| Базовые индикаторы | ✅ | ✅ |
| Дивергенции | Regular | Regular + Hidden |
| Swing detection | ✅ | ✅ |
| BOS/CHoCH | ✅ | ✅ |
| Volume climax | ✅ | ✅ |
| Конфигурация | ❌ | ✅ Адаптивная |
| Performance tracking | ❌ | ✅ Полный |
| MTF confluence | ❌ | ✅ |
| Order flow | ❌ | ✅ |
| Volume profile | ❌ | ✅ |
| Liquidity sweep | ❌ | ✅ |
| Weighted voting | Простое | ✅ С весами |
| Dynamic ATR | ❌ | ✅ |
| ML integration | ❌ | ✅ Готово |
| Unit тесты | ❌ | ✅ 40+ тестов |
| Документация | Минимальная | ✅ Полная |

---

## 🎯 Best Practices

### 1. Подбор конфигурации

```python
# Для агрессивной торговли
aggressive_config = {
    'min_score': 40,
    'rsi_oversold': 30,
    'volume_spike_threshold': 2.0,
}

# Для консервативной торговли
conservative_config = {
    'min_score': 70,
    'rsi_oversold': 25,
    'volume_spike_threshold': 4.0,
}

# Для скальпинга
scalping_config = {
    'swing_lookback': 2,  # Меньше свингов
    'min_score': 50,
    'enable_hidden_divergence': True,
}
```

### 2. Использование MTF confluence

Всегда используйте MTF когда возможно:

```python
# Плохо
result = detector.analyze(closes, highs, lows, volumes)

# Хорошо
result = detector.analyze(
    closes, highs, lows, volumes,
    klines_1h=klines_1h,  # Добавляет +10-15 к рейтингу если совпадает
    klines_4h=klines_4h
)
```

### 3. Проверка outcomes

Регулярно проверяйте результаты:

```python
# В главном цикле каждые 15 минут
for signal_id in active_signals:
    current_price = get_current_price(symbol)
    detector.check_signal_outcome(signal_id, current_price)

# Периодически выводим статистику
if iteration % 100 == 0:
    print(detector.get_performance_stats())
```

### 4. Фильтрация по confidence

Не входите в сделки с низкой уверенностью:

```python
result = detector.analyze(...)

if result['reversal']:
    if result['confidence'] < 60:
        print("Low confidence, skip")
        return
    
    # Уверенность >= 60% — можно входить
    enter_position(result)
```

### 5. Комбинация со screener

```python
# Screener находит setup
screener_signal = screener.analyze(symbol)

if screener_signal['type'] in ['BIG PUMP', 'BIG DUMP']:
    # Reversal detector проверяет не разворот ли это
    reversal_check = detector.analyze(...)
    
    if reversal_check['reversal']:
        # Возможно это ложный breakout
        print("⚠️ Possible false breakout!")
```

---

## ❓ FAQ

**Q: Какой минимальный рейтинг для входа?**  
A: Зависит от стиля. Консервативно — 70+, агрессивно — 50+.

**Q: Сколько данных нужно минимум?**  
A: 60 свечей, но лучше 100+ для надёжности.

**Q: Можно ли использовать на всех таймфреймах?**  
A: Да, но лучше работает на 5m-1h. На 1m слишком шумно, на 4h+ мало сигналов.

**Q: Как часто проверять разворот?**  
A: Каждые 30-60 секунд достаточно.

**Q: Hidden divergence точнее regular?**  
A: Нет, regular обычно надёжнее. Hidden — для продолжения тренда.

**Q: Нужно ли всегда использовать все фичи?**  
A: Нет, базовый анализ уже хорош. Дополнительные фичи повышают точность на 10-15%.

---

## 🔄 Changelog

### v5.0 (текущая)
- ✅ Адаптивные параметры через config
- ✅ Performance tracking с статистикой
- ✅ Advanced divergence (hidden + strength)
- ✅ Multi-timeframe confluence
- ✅ Order flow analysis
- ✅ Volume profile integration
- ✅ Liquidity sweep detection
- ✅ Weighted voting system
- ✅ Dynamic ATR filter
- ✅ ML integration hooks
- ✅ 40+ unit тестов
- ✅ Полная документация

### v4.2 (предыдущая)
- Regular divergence
- BOS/CHoCH
- Volume climax
- Simple voting
- Habr strategy

---

## 📝 License

Proprietary code. Все права защищены.

---

**Успешных разворотов! 🔄📈**
