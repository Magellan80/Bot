# reversal_detector.py

import time
import json
from typing import Dict, List, Optional, Tuple, Any
from collections import defaultdict
from dataclasses import dataclass, asdict


# ============================================================================
# PERFORMANCE TRACKING
# ============================================================================

@dataclass
class ReversalSignal:
    """Данные о сигнале разворота для трекинга"""
    signal_id: str
    timestamp: float
    direction: str  # bullish/bearish
    rating: int
    entry_price: float
    filters: List[str]
    outcome_checked: bool = False
    outcome_success: Optional[bool] = None
    exit_price: Optional[float] = None
    pnl_percent: Optional[float] = None


class ReversalPerformanceTracker:
    """Трекер производительности сигналов разворота"""
    
    def __init__(self, db_path: str = "reversal_performance.json"):
        self.db_path = db_path
        self.signals: Dict[str, ReversalSignal] = {}
        self.stats = {
            'total_signals': 0,
            'bullish_signals': 0,
            'bearish_signals': 0,
            'bullish_win_rate': 0.0,
            'bearish_win_rate': 0.0,
            'avg_pnl': 0.0,
            'best_filters': {},  # какие фильтры дают лучшие результаты
            'indicator_accuracy': {
                'rsi_divergence': 0.0,
                'macd_divergence': 0.0,
                'obv_divergence': 0.0,
                'bos': 0.0,
                'volume_climax': 0.0,
                'candle_conf': 0.0,
            }
        }
        self._load_from_disk()
    
    def _load_from_disk(self):
        try:
            with open(self.db_path, 'r') as f:
                data = json.load(f)
                self.signals = {k: ReversalSignal(**v) for k, v in data.get('signals', {}).items()}
                self.stats = data.get('stats', self.stats)
        except FileNotFoundError:
            pass
    
    def _save_to_disk(self):
        data = {
            'signals': {k: asdict(v) for k, v in self.signals.items()},
            'stats': self.stats
        }
        with open(self.db_path, 'w') as f:
            json.dump(data, f, indent=2)
    
    def add_signal(self, direction: str, rating: int, entry_price: float, filters: List[str]) -> str:
        """Добавить новый сигнал для отслеживания"""
        signal_id = f"rev_{int(time.time() * 1000)}"
        
        signal = ReversalSignal(
            signal_id=signal_id,
            timestamp=time.time(),
            direction=direction,
            rating=rating,
            entry_price=entry_price,
            filters=filters
        )
        
        self.signals[signal_id] = signal
        self.stats['total_signals'] += 1
        
        if direction == 'bullish':
            self.stats['bullish_signals'] += 1
        elif direction == 'bearish':
            self.stats['bearish_signals'] += 1
        
        self._save_to_disk()
        return signal_id
    
    def check_outcome(self, signal_id: str, current_price: float):
        """Проверка результата сигнала"""
        if signal_id not in self.signals:
            return
        
        signal = self.signals[signal_id]
        if signal.outcome_checked:
            return
        
        # Проверяем через 15+ минут
        if time.time() - signal.timestamp < 900:
            return
        
        signal.exit_price = current_price
        pnl_pct = ((current_price - signal.entry_price) / signal.entry_price) * 100
        signal.pnl_percent = pnl_pct
        
        # Определяем успех
        if signal.direction == 'bullish':
            signal.outcome_success = pnl_pct > 0.5
        else:  # bearish
            signal.outcome_success = pnl_pct < -0.5
        
        signal.outcome_checked = True
        self._update_stats()
        self._save_to_disk()
    
    def _update_stats(self):
        """Обновление статистики"""
        checked = [s for s in self.signals.values() if s.outcome_checked]
        if not checked:
            return
        
        # Win rates
        bullish_checked = [s for s in checked if s.direction == 'bullish']
        bearish_checked = [s for s in checked if s.direction == 'bearish']
        
        if bullish_checked:
            self.stats['bullish_win_rate'] = sum(1 for s in bullish_checked if s.outcome_success) / len(bullish_checked)
        if bearish_checked:
            self.stats['bearish_win_rate'] = sum(1 for s in bearish_checked if s.outcome_success) / len(bearish_checked)
        
        # Средний PnL
        pnls = [s.pnl_percent for s in checked if s.pnl_percent is not None]
        if pnls:
            self.stats['avg_pnl'] = sum(pnls) / len(pnls)
        
        # Лучшие фильтры
        filter_performance = defaultdict(lambda: {'total': 0, 'success': 0})
        for signal in checked:
            for filt in signal.filters:
                filter_performance[filt]['total'] += 1
                if signal.outcome_success:
                    filter_performance[filt]['success'] += 1
        
        self.stats['best_filters'] = {
            k: v['success'] / v['total'] if v['total'] > 0 else 0
            for k, v in filter_performance.items()
        }
        
        # Точность индикаторов
        for indicator in ['rsi_divergence', 'macd_divergence', 'obv_divergence', 'bos', 'volume_climax', 'candle_conf']:
            signals_with_indicator = [s for s in checked if any(indicator.replace('_', ' ').upper() in f.upper() for f in s.filters)]
            if signals_with_indicator:
                accuracy = sum(1 for s in signals_with_indicator if s.outcome_success) / len(signals_with_indicator)
                self.stats['indicator_accuracy'][indicator] = accuracy
    
    def get_stats_summary(self) -> str:
        """Форматированная статистика"""
        return (
            f"📊 Reversal Detector Stats:\n"
            f"Total: {self.stats['total_signals']} | "
            f"Bullish: {self.stats['bullish_signals']} | Bearish: {self.stats['bearish_signals']}\n"
            f"Win Rates: Bullish={self.stats['bullish_win_rate']:.1%} | Bearish={self.stats['bearish_win_rate']:.1%}\n"
            f"Avg PnL: {self.stats['avg_pnl']:.2f}%\n"
            f"Best Indicators: BOS={self.stats['indicator_accuracy']['bos']:.1%} | "
            f"RSI Div={self.stats['indicator_accuracy']['rsi_divergence']:.1%}"
        )


# ============================================================================
# MAIN REVERSAL DETECTOR CLASS
# ============================================================================

class ReversalDetector:
    """
    ReversalDetector v5.0 - Production Ready
    
    Новое в v5.0:
    - Адаптивные параметры через config
    - Performance tracking
    - Multi-timeframe confluence
    - Order flow analysis
    - Advanced divergence (hidden + regular)
    - Weighted voting system
    - Volume profile integration
    - Liquidity sweep detection
    - Dynamic ATR filter
    - ML score adjustment (опционально)
    """
    
    def __init__(self, config: Optional[Dict] = None):
        self.config = config or self._default_config()
        self.performance_tracker = ReversalPerformanceTracker()
        self.symbol_memory = {}  # Для адаптивных порогов по символам
    
    def _default_config(self) -> Dict:
        """Конфигурация по умолчанию"""
        return {
            # RSI
            'rsi_period': 14,
            'rsi_oversold': 35,
            'rsi_overbought': 65,
            'rsi_extreme_oversold': 25,
            'rsi_extreme_overbought': 75,
            
            # Trend
            'atr_trend_multiplier': 3.0,
            'min_trend_move': 20,  # минимальное движение в свечах
            
            # Volume
            'volume_spike_threshold': 3.0,
            'volume_lookback': 20,
            
            # BOS
            'bos_buffer_pct': 0.001,
            
            # Swings
            'swing_lookback': 3,
            
            # HTF
            'htf_sma_period': 40,
            'htf_threshold_pct': 1.5,
            
            # ATR Filter
            'atr_ultra_low': 0.4,
            'atr_low': 0.9,
            'atr_normal': 2.0,
            'atr_high': 4.0,
            
            # Scoring
            'min_score': 30,
            'divergence_weight': 18,
            'bos_weight': 24,
            'volume_weight': 14,
            'candle_weight': 10,
            'htf_weight': 10,
            
            # Habr strategy
            'bb_period': 20,
            'bb_mult': 2.0,
            'habr_min_atr': 0.2,
            'habr_max_atr': 5.0,
            'habr_min_score': 30,
            
            # Advanced features
            'enable_hidden_divergence': True,
            'enable_order_flow': True,
            'enable_volume_profile': True,
            'enable_liquidity_sweep': True,
            'enable_ml_adjustment': False,
        }
    
    # ============================
    #   ПУБЛИЧНЫЙ ИНТЕРФЕЙС
    # ============================
    
    def analyze(self, closes, highs, lows, volumes, 
                ob_imbalance=None, 
                klines_1h=None, 
                klines_4h=None,
                trades=None,
                volume_profile=None,
                liquidity_map=None):
        """
        Основной анализ разворота
        
        Args:
            closes, highs, lows, volumes: Базовые данные (1m/5m)
            ob_imbalance: Дисбаланс в orderbook
            klines_1h, klines_4h: Данные старших таймфреймов для confluence
            trades: Последние сделки для order flow
            volume_profile: Volume profile данные
            liquidity_map: Карта ликвидности
        """
        # Валидация
        if not (len(closes) == len(highs) == len(lows) == len(volumes)):
            return {"reversal": None, "rating": 0, "filters": ["Length mismatch"]}
        
        if len(closes) < 60:
            return {"reversal": None, "rating": 0, "filters": ["Not enough data"]}
        
        # Индикаторы
        rsi = self._rsi(closes, self.config['rsi_period'])
        macd_hist = self._macd_hist(closes)
        obv = self._obv(closes, volumes)
        atr = self._atr(highs, lows, closes)
        
        if min(len(rsi), len(macd_hist), len(obv), len(atr)) < 20:
            return {"reversal": None, "rating": 0, "filters": ["Not enough indicator data"]}
        
        # Свинги
        swings = self._swings(highs, lows, self.config['swing_lookback'])
        if len(swings) < 4:
            return {"reversal": None, "rating": 0, "filters": ["No swings"]}
        
        last_swings = swings[-6:]
        
        # Проверка тренда
        trend_ok, trend_dir = self._trend(closes, atr, last_swings)
        if not trend_ok:
            return {"reversal": None, "rating": 0, "filters": ["No trend → no reversal"]}
        
        filters = [f"Trend: {trend_dir}"]
        score = 0
        signal_data = {}  # Для ML
        
        # ========================================
        # ДИВЕРГЕНЦИИ (улучшенные)
        # ========================================
        
        rsi_div_result = self._advanced_divergence(rsi, closes, highs, lows, last_swings, 'RSI')
        macd_div_result = self._advanced_divergence(macd_hist, closes, highs, lows, last_swings, 'MACD')
        obv_div_result = self._advanced_divergence(obv, closes, highs, lows, last_swings, 'OBV')
        
        divergence_directions = []
        
        for div_result, name in [(rsi_div_result, 'RSI'), (macd_div_result, 'MACD'), (obv_div_result, 'OBV')]:
            if div_result['type']:
                div_type = "Hidden" if div_result['hidden'] else "Regular"
                filters.append(f"{name} {div_type} {div_result['type']} divergence (strength={div_result['strength']})")
                
                # Баллы с учётом силы
                base_points = self.config['divergence_weight']
                strength_bonus = (div_result['strength'] / 100) * 5
                score += base_points + strength_bonus
                
                divergence_directions.append(div_result['type'])
                signal_data[f'{name.lower()}_div'] = 1
            else:
                signal_data[f'{name.lower()}_div'] = 0
        
        # ========================================
        # BOS / CHOCH
        # ========================================
        
        bos, bos_dir = self._bos(closes, last_swings)
        if bos:
            filters.append(f"BOS/CHOCH {bos_dir}")
            score += self.config['bos_weight']
            signal_data['bos'] = 1
        else:
            score -= 8
            signal_data['bos'] = 0
        
        # ========================================
        # VOLUME CLIMAX
        # ========================================
        
        vol_climax, vol_dir = self._volume_climax(closes, highs, lows, volumes, self.config['volume_lookback'])
        if vol_climax:
            filters.append(f"Volume climax {vol_dir}")
            score += self.config['volume_weight']
            signal_data['volume_climax'] = 1
        else:
            signal_data['volume_climax'] = 0
        
        # ========================================
        # CANDLE CONFIRMATION
        # ========================================
        
        candle_conf, candle_dir = self._candle(closes, highs, lows)
        if candle_conf:
            filters.append(f"Candle confirmation {candle_dir}")
            score += self.config['candle_weight']
            signal_data['candle'] = 1
        else:
            signal_data['candle'] = 0
        
        # ========================================
        # ATR FILTER (динамический)
        # ========================================
        
        atr_ok, vol_regime = self._dynamic_atr_filter(atr, closes)
        if not atr_ok:
            filters.append("ATR noise filter fail")
            score -= 20
        else:
            filters.append(f"Volatility: {vol_regime}")
            score += 6
        signal_data['atr_pct'] = (atr[-1] / closes[-1] * 100) if closes[-1] > 0 else 0
        
        # ========================================
        # ORDERBOOK IMBALANCE
        # ========================================
        
        if ob_imbalance is not None:
            if ob_imbalance < -15:
                filters.append("Sell pressure (OB)")
                score += 10
            elif ob_imbalance > 15:
                filters.append("Buy pressure (OB)")
                score += 10
        
        # ========================================
        # HTF TREND
        # ========================================
        
        htf_ok, htf_dir = self._htf(closes)
        if htf_ok:
            filters.append(f"HTF trend {htf_dir}")
            score += self.config['htf_weight']
        
        # ========================================
        # MULTI-TIMEFRAME CONFLUENCE (новое!)
        # ========================================
        
        if klines_1h and klines_4h:
            mtf_result = self._mtf_confluence(klines_1h, klines_4h)
            if mtf_result['direction']:
                filters.append(f"MTF Confluence: {mtf_result['direction']} ({mtf_result['strength']})")
                score += mtf_result['strength'] // 5  # Бонус за MTF
                signal_data['mtf_aligned'] = 1
            else:
                signal_data['mtf_aligned'] = 0
        
        # ========================================
        # ORDER FLOW ANALYSIS (новое!)
        # ========================================
        
        if self.config['enable_order_flow'] and trades:
            flow_result = self._order_flow(trades)
            if flow_result['bias'] != 'neutral':
                filters.append(f"Order Flow: {flow_result['bias']} (delta={flow_result['delta']:.0f})")
                score += 12
                signal_data['order_flow'] = 1
            else:
                signal_data['order_flow'] = 0
        
        # ========================================
        # VOLUME PROFILE (новое!)
        # ========================================
        
        if self.config['enable_volume_profile'] and volume_profile:
            vp_result = self._volume_reversal_zones(closes, volume_profile)
            if vp_result['zone_strength'] > 0:
                filters.append(f"Volume Zone (POC={vp_result['near_poc']}, HVN={vp_result['near_hvn']})")
                score += vp_result['zone_strength'] // 4
                signal_data['near_vp_zone'] = 1
            else:
                signal_data['near_vp_zone'] = 0
        
        # ========================================
        # LIQUIDITY SWEEP (новое!)
        # ========================================
        
        if self.config['enable_liquidity_sweep'] and liquidity_map:
            liq_result = self._liquidity_reversal(liquidity_map, closes[-1])
            if liq_result['swept']:
                filters.append(f"Liquidity Sweep → {liq_result['direction']}")
                score += 18  # Важный сигнал!
                signal_data['liq_sweep'] = 1
            else:
                signal_data['liq_sweep'] = 0
        
        # ========================================
        # ДОПОЛНИТЕЛЬНЫЕ ФИЛЬТРЫ
        # ========================================
        
        # False divergence
        if divergence_directions and not bos:
            filters.append("Potential false divergence (no BOS)")
            score -= 12
        
        # Confluence bonus
        if bos and candle_conf and bos_dir == candle_dir:
            filters.append("BOS + Candle confluence")
            score += 6
        
        # Нормализация
        score = max(0, min(score, 100))
        
        if score < self.config['min_score']:
            return {"reversal": None, "rating": score, "filters": filters}
        
        # ========================================
        # ФИНАЛЬНОЕ НАПРАВЛЕНИЕ (улучшенное голосование)
        # ========================================
        
        signals_dict = {
            'rsi_div': rsi_div_result['type'],
            'macd_div': macd_div_result['type'],
            'obv_div': obv_div_result['type'],
            'bos': bos_dir if bos else None,
            'volume': vol_dir if vol_climax else None,
            'candle': candle_dir if candle_conf else None,
            'htf': htf_dir if htf_ok else None,
        }
        
        # Определяем режим рынка для взвешенного голосования
        market_regime = self._detect_market_regime(closes, atr)
        
        voting_result = self._weighted_voting(signals_dict, market_regime, rsi, macd_hist)
        direction = voting_result['direction']
        confidence = voting_result['confidence']
        
        if not direction:
            return {"reversal": None, "rating": score, "filters": filters}
        
        # ========================================
        # ML ADJUSTMENT (опционально)
        # ========================================
        
        if self.config['enable_ml_adjustment']:
            ml_adjustment = self._ml_score_adjustment(signal_data, score)
            score = ml_adjustment['adjusted_score']
            filters.append(f"ML confidence: {ml_adjustment['ml_confidence']:.1%}")
        
        # ========================================
        # PERFORMANCE TRACKING
        # ========================================
        
        signal_id = self.performance_tracker.add_signal(
            direction=direction,
            rating=score,
            entry_price=closes[-1],
            filters=filters
        )
        
        return {
            "reversal": direction,
            "rating": score,
            "confidence": confidence,
            "filters": filters,
            "signal_id": signal_id,
            "market_regime": market_regime
        }
    
    # ============================
    #   Habr-стратегия
    # ============================
    
    def analyze_habr(self, closes, highs, lows, volumes):
        """
        Habr++: Bollinger + RSI + EMA + ATR
        (без изменений, но с использованием config)
        """
        if len(closes) < 80:
            return None
        
        bb_upper, bb_mid, bb_lower = self._bbands(closes, self.config['bb_period'], self.config['bb_mult'])
        rsi = self._rsi(closes, self.config['rsi_period'])
        ema_fast = self._ema(closes, 20)
        ema_slow = self._ema(closes, 50)
        atr = self._atr(highs, lows, closes, period=14)
        
        if not (bb_upper and bb_lower and rsi and ema_fast and ema_slow and atr):
            return None
        
        c = closes[-1]
        upper = bb_upper[-1]
        lower = bb_lower[-1]
        r = rsi[-1]
        ema_f = ema_fast[-1]
        ema_s = ema_slow[-1]
        atr_last = atr[-1]
        
        atr_pct = atr_last / c * 100 if c > 0 else 0
        if atr_pct < self.config['habr_min_atr'] or atr_pct > self.config['habr_max_atr']:
            return None
        
        direction = None
        base_score = 0
        
        # Bullish mean-reversion
        if c < lower and r < self.config['rsi_oversold']:
            if c > ema_s * 0.97:
                direction = "bullish"
                dist_band = (lower - c) / lower * 100 if lower > 0 else 0
                rsi_score = max(0, 40 - r)
                base_score = dist_band * 2 + rsi_score * 1.5
        
        # Bearish mean-reversion
        if c > upper and r > self.config['rsi_overbought']:
            if c < ema_s * 1.03:
                direction = "bearish"
                dist_band = (c - upper) / upper * 100 if upper > 0 else 0
                rsi_score = max(0, r - 60)
                base_score = dist_band * 2 + rsi_score * 1.5
        
        if direction is None:
            return None
        
        # EMA trend adjustment
        ema_trend = ema_fast[-1] - ema_fast[-5] if len(ema_fast) >= 5 else 0
        if direction == "bullish" and ema_trend < 0:
            base_score *= 0.8
        if direction == "bearish" and ema_trend > 0:
            base_score *= 0.8
        
        rating = int(max(0, min(base_score, 100)))
        if rating < self.config['habr_min_score']:
            return None
        
        return {"direction": direction, "rating": rating}
    
    # ============================
    #   НОВЫЕ МЕТОДЫ v5.0
    # ============================
    
    def _advanced_divergence(self, indicator, closes, highs, lows, swings, name=''):
        """
        Продвинутая дивергенция с hidden divergence и strength scoring
        
        Returns:
            {
                'type': 'bullish'/'bearish'/None,
                'hidden': bool,
                'strength': 0-100,
                'swings_involved': int
            }
        """
        if len(swings) < 2 or len(indicator) < 10:
            return {'type': None, 'hidden': False, 'strength': 0, 'swings_involved': 0}
        
        # Проверяем последние 2 свинга (основная логика)
        last, prev = swings[-1], swings[-2]
        p1, p2 = prev["index"], last["index"]
        
        if p2 >= len(indicator) or p1 >= len(indicator):
            return {'type': None, 'hidden': False, 'strength': 0, 'swings_involved': 0}
        
        # Regular bullish divergence
        regular_bullish = False
        if last["type"] == "low" and prev["type"] == "low":
            if lows[p2] < lows[p1] and indicator[p2] > indicator[p1]:
                regular_bullish = True
        
        # Regular bearish divergence
        regular_bearish = False
        if last["type"] == "high" and prev["type"] == "high":
            if highs[p2] > highs[p1] and indicator[p2] < indicator[p1]:
                regular_bearish = True
        
        # Hidden divergence (если включено)
        hidden_bullish = False
        hidden_bearish = False
        
        if self.config['enable_hidden_divergence']:
            # Hidden bullish: цена делает higher low, индикатор lower low
            if last["type"] == "low" and prev["type"] == "low":
                if lows[p2] > lows[p1] and indicator[p2] < indicator[p1]:
                    hidden_bullish = True
            
            # Hidden bearish: цена делает lower high, индикатор higher high
            if last["type"] == "high" and prev["type"] == "high":
                if highs[p2] < highs[p1] and indicator[p2] > indicator[p1]:
                    hidden_bearish = True
        
        # Определяем тип и направление
        div_type = None
        is_hidden = False
        
        if regular_bullish:
            div_type = 'bullish'
        elif regular_bearish:
            div_type = 'bearish'
        elif hidden_bullish:
            div_type = 'bullish'
            is_hidden = True
        elif hidden_bearish:
            div_type = 'bearish'
            is_hidden = True
        
        if not div_type:
            return {'type': None, 'hidden': False, 'strength': 0, 'swings_involved': 0}
        
        # Расчёт силы дивергенции (угол расхождения)
        price_change = abs(highs[p2] - highs[p1]) if div_type == 'bearish' else abs(lows[p2] - lows[p1])
        indicator_change = abs(indicator[p2] - indicator[p1])
        
        # Нормализация (0-100)
        price_change_pct = (price_change / max(highs[p1], lows[p1], 1)) * 100
        indicator_change_normalized = min(indicator_change * 10, 100)  # Примерная нормализация
        
        strength = int(min((price_change_pct + indicator_change_normalized) / 2, 100))
        
        return {
            'type': div_type,
            'hidden': is_hidden,
            'strength': strength,
            'swings_involved': 2
        }
    
    def _mtf_confluence(self, klines_1h, klines_4h):
        """
        Multi-timeframe confluence analysis
        
        Returns:
            {
                'direction': 'bullish'/'bearish'/None,
                'strength': 0-100,
                'timeframes_aligned': ['1h', '4h']
            }
        """
        if not klines_1h or not klines_4h:
            return {'direction': None, 'strength': 0, 'timeframes_aligned': []}
        
        # Извлекаем closes
        closes_1h = [float(k[4]) for k in klines_1h]
        closes_4h = [float(k[4]) for k in klines_4h]
        
        if len(closes_1h) < 30 or len(closes_4h) < 30:
            return {'direction': None, 'strength': 0, 'timeframes_aligned': []}
        
        # Анализ тренда на 1h
        sma_1h = sum(closes_1h[-20:]) / 20
        trend_1h = None
        if closes_1h[-1] > sma_1h * 1.01:
            trend_1h = 'bullish'
        elif closes_1h[-1] < sma_1h * 0.99:
            trend_1h = 'bearish'
        
        # Анализ тренда на 4h
        sma_4h = sum(closes_4h[-20:]) / 20
        trend_4h = None
        if closes_4h[-1] > sma_4h * 1.015:
            trend_4h = 'bullish'
        elif closes_4h[-1] < sma_4h * 0.985:
            trend_4h = 'bearish'
        
        # Проверка совпадения
        aligned_tfs = []
        if trend_1h:
            aligned_tfs.append('1h')
        if trend_4h:
            aligned_tfs.append('4h')
        
        if trend_1h == trend_4h and trend_1h is not None:
            return {
                'direction': trend_1h,
                'strength': 85,
                'timeframes_aligned': aligned_tfs
            }
        
        return {'direction': None, 'strength': 0, 'timeframes_aligned': aligned_tfs}
    
    def _order_flow(self, trades, lookback=100):
        """
        Order flow analysis из последних сделок
        
        Returns:
            {
                'bias': 'bullish'/'bearish'/'neutral',
                'aggressive_buys': int,
                'aggressive_sells': int,
                'delta': float
            }
        """
        if not trades or len(trades) < 50:
            return {'bias': 'neutral', 'aggressive_buys': 0, 'aggressive_sells': 0, 'delta': 0}
        
        recent_trades = trades[-lookback:]
        
        # Агрессивные покупки (taker buy)
        agg_buys = sum(1 for t in recent_trades if not t.get('isBuyerMaker', True))
        
        # Агрессивные продажи (taker sell)
        agg_sells = sum(1 for t in recent_trades if t.get('isBuyerMaker', True))
        
        # Volume delta
        buy_volume = sum(float(t.get('qty', 0)) for t in recent_trades if not t.get('isBuyerMaker', True))
        sell_volume = sum(float(t.get('qty', 0)) for t in recent_trades if t.get('isBuyerMaker', True))
        
        delta = buy_volume - sell_volume
        
        # Определение bias
        bias = 'neutral'
        if delta > 0 and agg_buys > agg_sells * 1.3:
            bias = 'bullish'
        elif delta < 0 and agg_sells > agg_buys * 1.3:
            bias = 'bearish'
        
        return {
            'bias': bias,
            'aggressive_buys': agg_buys,
            'aggressive_sells': agg_sells,
            'delta': delta
        }
    
    def _volume_reversal_zones(self, closes, volume_profile):
        """
        Проверка разворота около volume profile зон
        
        Returns:
            {
                'near_poc': bool,
                'near_hvn': bool,
                'zone_strength': int
            }
        """
        if not volume_profile:
            return {'near_poc': False, 'near_hvn': False, 'zone_strength': 0}
        
        current_price = closes[-1]
        poc = volume_profile.get('poc')
        hvn_levels = volume_profile.get('high_volume_levels', [])
        
        if not poc:
            return {'near_poc': False, 'near_hvn': False, 'zone_strength': 0}
        
        # Проверка близости к POC (в пределах 0.3%)
        near_poc = abs(current_price - poc) / poc < 0.003 if poc > 0 else False
        
        # Проверка близости к HVN (в пределах 0.5%)
        near_hvn = any(abs(current_price - lvl) / lvl < 0.005 for lvl in hvn_levels if lvl > 0)
        
        zone_strength = 0
        if near_poc:
            zone_strength += 40
        if near_hvn:
            zone_strength += 30
        
        return {
            'near_poc': near_poc,
            'near_hvn': near_hvn,
            'zone_strength': zone_strength
        }
    
    def _liquidity_reversal(self, liquidity_map, current_price):
        """
        Проверка liquidity sweep и потенциального разворота
        
        Returns:
            {
                'swept': bool,
                'direction': 'bullish'/'bearish'/None,
                'zone_price': float
            }
        """
        if not liquidity_map:
            return {'swept': False, 'direction': None, 'zone_price': 0}
        
        strongest_zone = liquidity_map.get('strongest_zone')
        if not strongest_zone:
            return {'swept': False, 'direction': None, 'zone_price': 0}
        
        zone_price = strongest_zone.get('price', 0)
        zone_type = strongest_zone.get('type', '')
        
        swept = False
        reversal_direction = None
        
        # Sweep support → bullish reversal expected
        if zone_type == 'support' and current_price < zone_price * 0.998:
            swept = True
            reversal_direction = 'bullish'
        
        # Sweep resistance → bearish reversal expected
        elif zone_type == 'resistance' and current_price > zone_price * 1.002:
            swept = True
            reversal_direction = 'bearish'
        
        return {
            'swept': swept,
            'direction': reversal_direction,
            'zone_price': zone_price
        }
    
    def _dynamic_atr_filter(self, atr, closes):
        """
        Динамический ATR фильтр на основе истории символа
        """
        if not atr or not closes:
            return False, "unknown"
        
        atr_pct = (atr[-1] / closes[-1] * 100) if closes[-1] > 0 else 0
        
        # Можно адаптировать пороги на основе symbol_memory
        # Пока используем config
        
        if atr_pct < self.config['atr_ultra_low']:
            return False, "ultra_low"
        if atr_pct < self.config['atr_low']:
            return True, "low"
        if atr_pct < self.config['atr_normal']:
            return True, "normal"
        if atr_pct < self.config['atr_high']:
            return True, "high"
        
        return True, "extreme"
    
    def _detect_market_regime(self, closes, atr):
        """
        Определение режима рынка (trending/ranging/volatile)
        
        Returns:
            'trending' / 'ranging' / 'volatile'
        """
        if len(closes) < 50 or not atr:
            return 'ranging'
        
        # Движение за последние 30 свечей
        move = abs(closes[-1] - closes[-31])
        avg_price = sum(closes[-30:]) / 30
        move_pct = (move / avg_price * 100) if avg_price > 0 else 0
        
        # ATR процент
        atr_pct = (atr[-1] / closes[-1] * 100) if closes[-1] > 0 else 0
        
        if atr_pct > 3.0:
            return 'volatile'
        elif move_pct > 5.0:
            return 'trending'
        else:
            return 'ranging'
    
    def _weighted_voting(self, signals_dict, market_regime, rsi, macd_hist):
        """
        Улучшенное взвешенное голосование
        
        Returns:
            {
                'direction': 'bullish'/'bearish'/None,
                'confidence': 0-100
            }
        """
        # Базовые веса (можно брать из performance stats)
        weights = {
            'bos': 30,
            'rsi_div': 18,
            'macd_div': 16,
            'obv_div': 14,
            'volume': 15,
            'candle': 10,
            'htf': 15,
        }
        
        # Адаптация весов по режиму рынка
        if market_regime == 'trending':
            weights['bos'] += 10
            weights['rsi_div'] -= 5
            weights['macd_div'] -= 5
        elif market_regime == 'ranging':
            weights['rsi_div'] += 10
            weights['macd_div'] += 10
            weights['bos'] -= 5
        elif market_regime == 'volatile':
            # В волатильном рынке больше доверяем volume и candles
            weights['volume'] += 10
            weights['candle'] += 5
        
        # Подсчёт взвешенных голосов
        bullish_score = 0
        bearish_score = 0
        
        for signal_name, direction in signals_dict.items():
            if direction == 'bullish':
                bullish_score += weights.get(signal_name, 5)
            elif direction == 'bearish':
                bearish_score += weights.get(signal_name, 5)
        
        # RSI zones
        if rsi and len(rsi) > 0:
            if rsi[-1] < 45:
                bullish_score += 5
            elif rsi[-1] > 55:
                bearish_score += 5
        
        # MACD zero-cross
        if macd_hist and len(macd_hist) > 3:
            if macd_hist[-1] > 0 and macd_hist[-2] < 0:
                bullish_score += 8
            elif macd_hist[-1] < 0 and macd_hist[-2] > 0:
                bearish_score += 8
        
        # Определение победителя
        total_score = bullish_score + bearish_score
        if total_score == 0:
            return {'direction': None, 'confidence': 0}
        
        # Требуем перевес минимум 1.3x
        if bullish_score > bearish_score * 1.3:
            confidence = int((bullish_score / total_score) * 100)
            return {'direction': 'bullish', 'confidence': confidence}
        elif bearish_score > bullish_score * 1.3:
            confidence = int((bearish_score / total_score) * 100)
            return {'direction': 'bearish', 'confidence': confidence}
        
        return {'direction': None, 'confidence': 0}
    
    def _ml_score_adjustment(self, signal_data, base_score):
        """
        ML-based score adjustment (заглушка для будущей реализации)
        
        Здесь можно интегрировать sklearn модель:
        1. Обучить на исторических данных
        2. Предсказать вероятность успеха
        3. Скорректировать score
        """
        # TODO: Implement actual ML model
        # For now, return unchanged
        
        ml_confidence = 0.5  # Нейтральная вероятность
        adjusted_score = base_score
        
        return {
            'adjusted_score': adjusted_score,
            'ml_confidence': ml_confidence
        }
    
    # ============================
    #   БАЗОВЫЕ МЕТОДЫ (без изменений)
    # ============================
    
    def _trend(self, closes, atr, swings):
        """Проверка наличия тренда"""
        if len(closes) < 30 or len(atr) < 20:
            return False, None
        
        move = abs(closes[-1] - closes[-21])
        if move < atr[-1] * self.config['atr_trend_multiplier']:
            return False, None
        
        last, prev, prev2 = swings[-1], swings[-2], swings[-3]
        
        if prev2["type"] == "low" and prev["type"] == "high" and last["type"] == "low":
            return True, "bullish_trend"
        
        if prev2["type"] == "high" and prev["type"] == "low" and last["type"] == "high":
            return True, "bearish_trend"
        
        return False, None
    
    def _rsi(self, closes, period=14):
        """RSI индикатор"""
        if len(closes) < period + 2:
            return []
        gains = [max(closes[i] - closes[i - 1], 0) for i in range(1, len(closes))]
        losses = [max(closes[i - 1] - closes[i], 0) for i in range(1, len(closes))]
        
        avg_gain = sum(gains[:period]) / period
        avg_loss = sum(losses[:period]) / period
        
        out = []
        for i in range(period, len(gains)):
            avg_gain = (avg_gain * (period - 1) + gains[i]) / period
            avg_loss = (avg_loss * (period - 1) + losses[i]) / period
            rs = avg_gain / avg_loss if avg_loss != 0 else 0
            rsi = 100 - (100 / (1 + rs))
            out.append(rsi)
        return out
    
    def _ema(self, values, period):
        """EMA индикатор"""
        if not values or len(values) < period:
            return []
        k = 2 / (period + 1)
        ema = sum(values[:period]) / period
        out = [ema]
        for v in values[period:]:
            ema = v * k + ema * (1 - k)
            out.append(ema)
        return out
    
    def _macd_hist(self, closes):
        """MACD Histogram"""
        if len(closes) < 40:
            return []
        fast = self._ema(closes, 12)
        slow = self._ema(closes, 26)
        if not fast or not slow:
            return []
        macd = [f - s for f, s in zip(fast[-len(slow):], slow)]
        signal = self._ema(macd, 9)
        if not signal:
            return []
        hist = [m - s for m, s in zip(macd[-len(signal):], signal)]
        return hist
    
    def _obv(self, closes, volumes):
        """On Balance Volume"""
        if len(closes) != len(volumes):
            return []
        obv = [0]
        for i in range(1, len(closes)):
            if closes[i] > closes[i - 1]:
                obv.append(obv[-1] + volumes[i])
            elif closes[i] < closes[i - 1]:
                obv.append(obv[-1] - volumes[i])
            else:
                obv.append(obv[-1])
        return obv
    
    def _atr(self, highs, lows, closes, period=14):
        """Average True Range"""
        if len(closes) < period + 2:
            return []
        trs = []
        for i in range(1, len(closes)):
            trs.append(max(
                highs[i] - lows[i],
                abs(highs[i] - closes[i - 1]),
                abs(lows[i] - closes[i - 1])
            ))
        atr = sum(trs[:period]) / period
        out = [atr]
        for tr in trs[period:]:
            atr = (atr * (period - 1) + tr) / period
            out.append(atr)
        return out
    
    def _bbands(self, closes, period=20, mult=2.0):
        """Bollinger Bands"""
        if len(closes) < period:
            return [], [], []
        ma = []
        stds = []
        for i in range(period, len(closes) + 1):
            window = closes[i - period:i]
            m = sum(window) / period
            ma.append(m)
            var = sum((x - m) ** 2 for x in window) / period
            stds.append(var ** 0.5)
        upper = [m + mult * s for m, s in zip(ma, stds)]
        lower = [m - mult * s for m, s in zip(ma, stds)]
        return upper, ma, lower
    
    def _swings(self, highs, lows, lookback=3):
        """Swing High/Low detection"""
        out = []
        for i in range(lookback, len(highs) - lookback):
            if all(highs[i] > highs[i - j] and highs[i] > highs[i + j] for j in range(1, lookback + 1)):
                out.append({"type": "high", "index": i})
            elif all(lows[i] < lows[i - j] and lows[i] < lows[i + j] for j in range(1, lookback + 1)):
                out.append({"type": "low", "index": i})
        return out
    
    def _bos(self, closes, swings):
        """Break of Structure / Change of Character"""
        last = swings[-1]
        idx = last["index"]
        level = closes[idx]
        last_close = closes[-1]
        
        buffer = abs(level) * self.config['bos_buffer_pct']
        
        if last["type"] == "high":
            if last_close > level + buffer:
                return True, "bullish"
        if last["type"] == "low":
            if last_close < level - buffer:
                return True, "bearish"
        
        return False, None
    
    def _volume_climax(self, closes, highs, lows, volumes, lookback=20):
        """Volume climax detection"""
        if len(volumes) < lookback + 5:
            return False, None
        
        avg = sum(volumes[-lookback - 1:-1]) / lookback
        if avg == 0:
            return False, None
        
        spike = volumes[-1] / avg
        body = abs(closes[-1] - closes[-2])
        rng = highs[-1] - lows[-1] or 1e-7
        
        if spike > self.config['volume_spike_threshold'] and body / rng > 0.55:
            return True, "bullish" if closes[-1] > closes[-2] else "bearish"
        
        return False, None
    
    def _candle(self, closes, highs, lows):
        """Candle pattern confirmation"""
        if len(closes) < 4:
            return False, None
        
        c0, c1, c2 = closes[-1], closes[-2], closes[-3]
        h0, h1, h2 = highs[-1], highs[-2], highs[-3]
        l0, l1, l2 = lows[-1], lows[-2], lows[-3]
        
        # Bullish: длинный нижний хвост
        if l0 < min(l1, l2) and (c0 - l0) > (h0 - c0) * 1.3 and c0 > c1:
            return True, "bullish"
        
        # Bearish: длинный верхний хвост
        if h0 > max(h1, h2) and (h0 - c0) > (c0 - l0) * 1.3 and c0 < c1:
            return True, "bearish"
        
        return False, None
    
    def _htf(self, closes, period=None):
        """Higher timeframe trend"""
        if period is None:
            period = self.config['htf_sma_period']
        
        if len(closes) < period + 5:
            return False, None
        
        sma = sum(closes[-period - 1:-1]) / period
        price = closes[-1]
        threshold_pct = self.config['htf_threshold_pct'] / 100
        
        if price > sma * (1 + threshold_pct):
            return True, "bullish"
        if price < sma * (1 - threshold_pct):
            return True, "bearish"
        
        return True, "flat"
    
    # ============================
    #   УТИЛИТЫ
    # ============================
    
    def get_performance_stats(self) -> str:
        """Получить статистику производительности"""
        return self.performance_tracker.get_stats_summary()
    
    def update_config(self, new_config: Dict):
        """Обновить конфигурацию"""
        self.config.update(new_config)
    
    def check_signal_outcome(self, signal_id: str, current_price: float):
        """Проверить результат сигнала"""
        self.performance_tracker.check_outcome(signal_id, current_price)
